Night Terror is a the the gtk version of my Night Terror Plasma theme and color-scheme for use in KDE Plasma for more uniform look and feel.
